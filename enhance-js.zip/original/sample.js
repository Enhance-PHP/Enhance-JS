var Sample = (function () {
    return {
        addTwoNumbers: function (a, b) {
            return 5;
        }
    };
}());